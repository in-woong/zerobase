## Modal Popup

- 모달 팝업 구현
- 버튼 누르면 팝업 띄우기
- 닫기, 모달 바깥 배경 누르면 팝업 닫기
- 팝업 띄울 시 바깥 스크롤 되지 않게 구현

### toggle

https://developer.mozilla.org/ko/docs/Web/API/Element/classList

- 하나의 설정 값으로부터 다른 값으로 전환