;(function () {
  'use strict'
  const get = (target) => {
    return document.querySelector(target)
  }
})()
